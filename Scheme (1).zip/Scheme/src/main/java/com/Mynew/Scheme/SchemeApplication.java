package com.Mynew.Scheme;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchemeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SchemeApplication.class, args);
	}

}
